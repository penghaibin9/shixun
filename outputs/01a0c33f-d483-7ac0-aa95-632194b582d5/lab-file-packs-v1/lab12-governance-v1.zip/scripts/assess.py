from pathlib import Path
import csv,json
Path('work').mkdir(exist_ok=True)
def read(name): return list(csv.DictReader(Path(name).open(encoding='utf-8')))
assets={x['asset_id']:x for x in read('data/assets.csv')}
controls={x['control_id']:x for x in read('data/controls.csv')}
risks=read('data/risks.csv'); remediation=[]
for risk in risks:
    assert risk['asset_id'] in assets and risk['control_id'] in controls
    control=controls[risk['control_id']]
    if control['status']!='DONE':
        remediation.append({'risk_id':risk['risk_id'],'asset':assets[risk['asset_id']]['name'],'severity':risk['severity'],'control_id':risk['control_id'],'status':control['status'],'owner':control['owner'],'due_date':control['due_date']})
with Path('work/remediation.csv').open('w',encoding='utf-8',newline='') as f:
    fields=['risk_id','asset','severity','control_id','status','owner','due_date']; w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(remediation)
summary={'assets':len(assets),'risks':len(risks),'open_remediation':len(remediation),'completed_controls':sum(x['status']=='DONE' for x in controls.values())}
assert summary=={'assets':3,'risks':3,'open_remediation':2,'completed_controls':1}
Path('work/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print('LAB12_PASS',summary)
