from pathlib import Path
import base64, json
Path('work').mkdir(exist_ok=True)
source=Path('data/message.txt').read_bytes()
encoded=base64.b64encode(source)
decoded=base64.b64decode(encoded, validate=True)
assert decoded==source
Path('work/encoded.txt').write_bytes(encoded+b'\n')
Path('work/decoded.txt').write_bytes(decoded)
report={'source_bytes':len(source),'encoded_bytes':len(encoded),'roundtrip':True,'confidentiality':False}
Path('work/report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('LAB06_PASS', report)
