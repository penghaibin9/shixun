#!/bin/sh
set -eu
mkdir -p work
export LAB_PASSWORD=${LAB_PASSWORD:-Yueke-Lab-Only-2026}
sha256sum data/plaintext.txt > work/source.sha256
openssl enc -aes-256-cbc -salt -pbkdf2 -in data/plaintext.txt -out work/cipher.bin -pass env:LAB_PASSWORD
openssl enc -d -aes-256-cbc -pbkdf2 -in work/cipher.bin -out work/plain.out -pass env:LAB_PASSWORD
cmp data/plaintext.txt work/plain.out
printf 'AES_ROUNDTRIP_PASS\n' > work/result.txt
set +e
openssl enc -des-cbc -salt -pbkdf2 -in data/plaintext.txt -out work/des.bin -pass env:LAB_PASSWORD >/dev/null 2>&1
status=$?
set -e
printf 'DES_EXIT=%s\nDES仅用于观察遗留兼容性，不作为安全方案。\n' "$status" > work/des-observation.txt
