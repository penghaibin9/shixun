from pathlib import Path
import hashlib
source = Path('data/plaintext.txt').read_bytes()
plain = Path('work/plain.out').read_bytes()
assert source == plain
assert Path('work/cipher.bin').read_bytes() != source
print('LAB01_PASS', hashlib.sha256(source).hexdigest())
