#!/bin/sh
set -eu
mkdir -p work
cp data/evidence.txt work/changed.txt
sha256sum data/evidence.txt | awk '{print $1}' > work/original.sha256
printf '2026-09-22,student-001,LOGIN_FAILED\n' > work/changed.txt
sha256sum work/changed.txt | awk '{print $1}' > work/changed.sha256
test "$(cat work/original.sha256)" != "$(cat work/changed.sha256)"
python3 - <<'PY'
from pathlib import Path
import json
result={'original':Path('work/original.sha256').read_text().strip(),'changed':Path('work/changed.sha256').read_text().strip(),'different':True}
Path('work/integrity-report.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print('LAB05_PASS')
PY
