from pathlib import Path
import csv,json
from collections import Counter
Path('work').mkdir(exist_ok=True)
rows=list(csv.DictReader(Path('data/access.csv').open(encoding='utf-8')))
failed=Counter(row['user'] for row in rows if row['action']=='LOGIN' and row['result']=='FAILED')
alerts=[]
for user,count in failed.items():
    if count>=5: alerts.append({'rule':'FIVE_FAILED_LOGINS','user':user,'count':count})
for row in rows:
    if row['result']=='DENIED': alerts.append({'rule':'ACCESS_DENIED','user':row['user'],'action':row['action'],'timestamp':row['timestamp']})
assert {a['rule'] for a in alerts}=={'FIVE_FAILED_LOGINS','ACCESS_DENIED'}
Path('work/alerts.json').write_text(json.dumps(alerts,ensure_ascii=False,indent=2),encoding='utf-8')
Path('work/summary.json').write_text(json.dumps({'events':len(rows),'alerts':len(alerts)},indent=2),encoding='utf-8')
print('LAB11_PASS',alerts)
