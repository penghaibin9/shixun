from pathlib import Path
import json
Path('work').mkdir(exist_ok=True)
width=height=32
pixels=bytearray([120,180,220]*(width*height))
header=f'P6\n{width} {height}\n255\n'.encode()
Path('work/carrier.ppm').write_bytes(header+pixels)
message=Path('data/secret.txt').read_bytes()
payload=len(message).to_bytes(4,'big')+message
bits=[(byte>>shift)&1 for byte in payload for shift in range(7,-1,-1)]
assert len(bits)<=len(pixels)
stego=bytearray(pixels)
for i,bit in enumerate(bits): stego[i]=(stego[i]&0xfe)|bit
Path('work/stego.ppm').write_bytes(header+stego)
read_bits=[value&1 for value in stego]
def take(start,count):
    out=bytearray()
    for offset in range(start,start+count,8):
        value=0
        for bit in read_bits[offset:offset+8]: value=(value<<1)|bit
        out.append(value)
    return bytes(out)
length=int.from_bytes(take(0,32),'big')
extracted=take(32,length*8)
assert extracted==message
Path('work/extracted.txt').write_bytes(extracted)
report={'message_bytes':length,'embedded_bits':len(bits),'changed_channels':sum(a!=b for a,b in zip(pixels,stego))}
Path('work/report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print('LAB07_PASS', report)
