from pathlib import Path
import csv, json, re
Path('work').mkdir(exist_ok=True)
rows=list(csv.DictReader(Path('data/input.csv').open(encoding='utf-8')))
out=[]; invalid=0
for row in rows:
    phone=row['phone']; card=row['id_card']
    if phone and re.fullmatch(r'1\d{10}',phone): phone=phone[:3]+'****'+phone[-4:]
    elif phone: phone='格式异常'; invalid+=1
    if card and re.fullmatch(r'\d{17}[0-9Xx]',card): card=card[:6]+'********'+card[-4:].upper()
    elif card: card='格式异常'; invalid+=1
    out.append({'name':row['name'],'phone':phone,'id_card':card})
with Path('work/masked.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['name','phone','id_card']); w.writeheader(); w.writerows(out)
report={'rows':len(out),'invalid_fields':invalid,'raw_sensitive_values_in_output':False}
text=Path('work/masked.csv').read_text(encoding='utf-8')
assert '13812345678' not in text and '110101199001011234' not in text
Path('work/report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('LAB09_PASS',report)
