CREATE TABLE lab_orders (order_id BIGINT PRIMARY KEY, customer_masked VARCHAR(32) NOT NULL, amount_cents BIGINT NOT NULL);
CREATE TABLE lab_audit_view_source (event_id BIGINT PRIMARY KEY, action_name VARCHAR(64) NOT NULL);
INSERT INTO lab_orders VALUES (1, '138****5678', 9900);
