CREATE ROLE 'lab_reader', 'lab_operator', 'lab_auditor';
GRANT SELECT ON lab_orders TO 'lab_reader';
GRANT SELECT, INSERT, UPDATE ON lab_orders TO 'lab_operator';
GRANT SELECT ON lab_audit_view_source TO 'lab_auditor';
-- 教学环境执行后，应使用 REVOKE 和 DROP ROLE 完成清理。
