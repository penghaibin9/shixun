from pathlib import Path
schema=Path('sql/schema.sql').read_text(encoding='utf-8')
roles=Path('sql/roles.sql').read_text(encoding='utf-8')
matrix=Path('checks/permission-matrix.csv').read_text(encoding='utf-8').splitlines()
assert 'CREATE TABLE lab_orders' in schema
assert "CREATE ROLE 'lab_reader'" in roles
assert 'DROP' in matrix[0] or 'drop_orders' in matrix[0]
assert len(matrix)==4
print('LAB08_PACKAGE_PASS')
