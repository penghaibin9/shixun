#!/bin/sh
set -eu
mkdir -p work
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out work/private.pem >/dev/null 2>&1
openssl pkey -in work/private.pem -pubout -out work/public.pem >/dev/null 2>&1
openssl dgst -sha256 -sign work/private.pem -out work/signature.bin data/message.txt
openssl dgst -sha256 -verify work/public.pem -signature work/signature.bin data/message.txt > work/verify-original.txt
printf '跃科数字签名完整性实验！\n' > work/tampered.txt
set +e
openssl dgst -sha256 -verify work/public.pem -signature work/signature.bin work/tampered.txt > work/verify-tampered.txt 2>&1
status=$?
set -e
test "$status" -ne 0
grep -q 'Verified OK' work/verify-original.txt
printf 'SIGNATURE_POSITIVE_AND_NEGATIVE_PASS\n' > work/result.txt
