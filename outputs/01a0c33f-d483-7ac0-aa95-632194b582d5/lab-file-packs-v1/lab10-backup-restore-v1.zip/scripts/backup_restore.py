from pathlib import Path
import hashlib,json,time,zipfile
start=time.perf_counter(); Path('work/restored').mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile('work/full.zip','w',zipfile.ZIP_DEFLATED) as z: z.write('data/records.json','records.json')
Path('work/incremental.json').write_bytes(Path('data/incremental.json').read_bytes())
with zipfile.ZipFile('work/full.zip') as z: z.extractall('work/restored')
records={x['id']:x for x in json.loads(Path('work/restored/records.json').read_text())}
change=json.loads(Path('work/incremental.json').read_text())
for item in change['upsert']: records[item['id']]=item
for key in change['delete']: records.pop(key,None)
final=[records[key] for key in sorted(records)]
Path('work/restored/records.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),encoding='utf-8')
digest=hashlib.sha256(Path('work/restored/records.json').read_bytes()).hexdigest()
assert final==[{'id':1,'value':'alpha'},{'id':2,'value':'beta-v2'},{'id':3,'value':'gamma'}]
report={'rpo_example_minutes':15,'rto_example_minutes':60,'restore_seconds':round(time.perf_counter()-start,4),'sha256':digest,'verified':True}
Path('work/report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('LAB10_PASS',report)
