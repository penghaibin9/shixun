#!/bin/sh
set -eu
mkdir -p work
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out work/private.pem >/dev/null 2>&1
chmod 600 work/private.pem
openssl pkey -in work/private.pem -pubout -out work/public.pem >/dev/null 2>&1
openssl pkeyutl -encrypt -pubin -inkey work/public.pem -in data/message.txt -out work/cipher.bin -pkeyopt rsa_padding_mode:oaep
openssl pkeyutl -decrypt -inkey work/private.pem -in work/cipher.bin -out work/plain.out -pkeyopt rsa_padding_mode:oaep
cmp data/message.txt work/plain.out
printf 'RSA_ROUNDTRIP_PASS\n' > work/result.txt
