from pathlib import Path
assert Path('work/private.pem').read_text().startswith('-----BEGIN PRIVATE KEY-----')
assert Path('work/public.pem').read_text().startswith('-----BEGIN PUBLIC KEY-----')
assert Path('data/message.txt').read_bytes() == Path('work/plain.out').read_bytes()
print('LAB03_PASS')
