#!/bin/sh
set -eu
mkdir -p data work
python3 - <<'PY'
from pathlib import Path
Path('data/repeated.bin').write_bytes(b'YUEKE-BLOCK-0001' * 4)
PY
KEY=00112233445566778899aabbccddeeff
IV=0102030405060708090a0b0c0d0e0f10
openssl enc -aes-128-ecb -nopad -nosalt -K "$KEY" -in data/repeated.bin -out work/ecb.bin
openssl enc -aes-128-cbc -nopad -nosalt -K "$KEY" -iv "$IV" -in data/repeated.bin -out work/cbc.bin
python3 checks/verify.py
