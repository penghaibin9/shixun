from pathlib import Path
import json
ecb = Path('work/ecb.bin').read_bytes()
cbc = Path('work/cbc.bin').read_bytes()
ecb_blocks = [ecb[i:i+16] for i in range(0, len(ecb), 16)]
cbc_blocks = [cbc[i:i+16] for i in range(0, len(cbc), 16)]
result = {'ecb_total': len(ecb_blocks), 'ecb_unique': len(set(ecb_blocks)), 'cbc_total': len(cbc_blocks), 'cbc_unique': len(set(cbc_blocks))}
assert result['ecb_unique'] == 1
assert result['cbc_unique'] == result['cbc_total'] == 4
Path('work/comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print('LAB02_PASS', result)
